function globalTeardown() {
	console.log("##[section]Teardown Playwright Test Environment.");
}
export default globalTeardown;